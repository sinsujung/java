package com.test.question;

public class Q009 {
	
	public static void main(String[] args) {
		
			
	}//main

	public static String getName(String name) {
		return "고객명:" + name ;
	}
	
}
